// import 'dart:convert';
//
// class JewelryItem {
//   final String barcode;
//   final String location;
//   final String branch;
//   final String status;
//   final String source;
//   final String category;
//   final String description;
//   final String metalGroup;
//   final String inStockSince;
//   final String certNo;
//   final String huidNo;
//   final String cusName;
//   final double grossWt;
//   final double netWt;
//   final double mrp;
//   final String imageLink;
//   final List<TableData> tableData;
//
//   JewelryItem({
//     required this.barcode,
//     required this.location,
//     required this.branch,
//     required this.status,
//     required this.source,
//     required this.category,
//     required this.description,
//     required this.metalGroup,
//     required this.inStockSince,
//     required this.certNo,
//     required this.huidNo,
//     required this.cusName,
//     required this.grossWt,
//     required this.netWt,
//     required this.mrp,
//     required this.imageLink,
//     required this.tableData,
//   });
//
//   factory JewelryItem.fromJson(Map<String, dynamic> json) {
//     var list = json['Table_Data'] as List;
//     List<TableData> tableDataList =
//     list.map((i) => TableData.fromJson(i)).toList();
//
//     return JewelryItem(
//       barcode: json['Barcode'],
//       location: json['Location'],
//       branch: json['Branch'],
//       status: json['Status'],
//       source: json['Source'],
//       category: json['Category'],
//       description: json['Description'],
//       metalGroup: json['Metal_Grp'],
//       inStockSince: json['In_STK_Since'],
//       certNo: json['Cert_No'],
//       huidNo: json['HUID_No'],
//       cusName: json['Cus_Name'],
//       grossWt: json['Gross_Wt'],
//       netWt: json['Net_Wt'],
//       mrp: json['MRP'],
//       imageLink: json['image_link'],
//       tableData: tableDataList,
//     );
//   }
// }
//
// class TableData {
//   final String lotDescription;
//   final String group;
//   final String units;
//   final int pcs;
//   final double weight;
//
//   TableData({
//     required this.lotDescription,
//     required this.group,
//     required this.units,
//     required this.pcs,
//     required this.weight,
//   });
//
//   factory TableData.fromJson(Map<String, dynamic> json) {
//     return TableData(
//       lotDescription: json['Lot_Description'],
//       group: json['Group'],
//       units: json['Units'],
//       pcs: json['Pcs'],
//       weight: json['Weight'],
//     );
//   }
// }


class JewelryItem {
  String barcode;
  String location;
  String branch;
  String status;
  int counter;
  String source;
  String category;
  String collection;
  String description;
  String metalGrp;
  String stkSection;
  String mfgdBy;
  String notes;
  String inStkSince;
  String certNo;
  String huidNo;
  int orderNo;
  String cusName;
  String size;
  String quality;
  double kt;
  int pcs;
  double grossWt;
  double netWt;
  int diaPcs;
  double diaWt;
  int clsPcs;
  double clsWt;
  double chainWt;
  double mRate;
  double mValue;
  double lRate;
  double lCharges;
  double rCharges;
  double oCharges;
  double mrp;
  String imageLink;
  List<TableData> tableData;

  JewelryItem({
    required this.barcode,
    required this.location,
    required this.branch,
    required this.status,
    required this.counter,
    required this.source,
    required this.category,
    required this.collection,
    required this.description,
    required this.metalGrp,
    required this.stkSection,
    required this.mfgdBy,
    required this.notes,
    required this.inStkSince,
    required this.certNo,
    required this.huidNo,
    required this.orderNo,
    required this.cusName,
    required this.size,
    required this.quality,
    required this.kt,
    required this.pcs,
    required this.grossWt,
    required this.netWt,
    required this.diaPcs,
    required this.diaWt,
    required this.clsPcs,
    required this.clsWt,
    required this.chainWt,
    required this.mRate,
    required this.mValue,
    required this.lRate,
    required this.lCharges,
    required this.rCharges,
    required this.oCharges,
    required this.mrp,
    required this.imageLink,
    required this.tableData,
  });

  factory JewelryItem.fromJson(Map<String, dynamic> json) {
    return JewelryItem(
      barcode: json['Barcode'],
      location: json['Location'],
      branch: json['Branch'],
      status: json['Status'],
      counter: json['Counter'],
      source: json['Source'],
      category: json['Category'],
      collection: json['Collection'],
      description: json['Description'],
      metalGrp: json['Metal_Grp'],
      stkSection: json['STK_Section'],
      mfgdBy: json['Mfgd_By'],
      notes: json['Notes'],
      inStkSince: json['In_STK_Since'],
      certNo: json['Cert_No'],
      huidNo: json['HUID_No'],
      orderNo: json['Order_No'],
      cusName: json['Cus_Name'],
      size: json['Size'],
      quality: json['Quality'],
      kt: json['KT'].toDouble(),
      pcs: json['Pcs'],
      grossWt: json['Gross_Wt'].toDouble(),
      netWt: json['Net_Wt'].toDouble(),
      diaPcs: json['Dia_Pcs'],
      diaWt: json['Dia_Wt'].toDouble(),
      clsPcs: json['Cls_Pcs'],
      clsWt: json['Cls_Wt'].toDouble(),
      chainWt: json['Chain_Wt'].toDouble(),
      mRate: json['M_Rate'].toDouble(),
      mValue: json['M_Value'].toDouble(),
      lRate: json['L_Rate'].toDouble(),
      lCharges: json['L_Charges'].toDouble(),
      rCharges: json['R_Charges'].toDouble(),
      oCharges: json['O_Charges'].toDouble(),
      mrp: json['MRP'].toDouble(),
      imageLink: json['image_link'],
      tableData: (json['Table_Data'] as List)
          .map((data) => TableData.fromJson(data))
          .toList(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'Barcode': barcode,
      'Location': location,
      'Branch': branch,
      'Status': status,
      'Counter': counter,
      'Source': source,
      'Category': category,
      'Collection': collection,
      'Description': description,
      'Metal_Grp': metalGrp,
      'STK_Section': stkSection,
      'Mfgd_By': mfgdBy,
      'Notes': notes,
      'In_STK_Since': inStkSince,
      'Cert_No': certNo,
      'HUID_No': huidNo,
      'Order_No': orderNo,
      'Cus_Name': cusName,
      'Size': size,
      'Quality': quality,
      'KT': kt,
      'Pcs': pcs,
      'Gross_Wt': grossWt,
      'Net_Wt': netWt,
      'Dia_Pcs': diaPcs,
      'Dia_Wt': diaWt,
      'Cls_Pcs': clsPcs,
      'Cls_Wt': clsWt,
      'Chain_Wt': chainWt,
      'M_Rate': mRate,
      'M_Value': mValue,
      'L_Rate': lRate,
      'L_Charges': lCharges,
      'R_Charges': rCharges,
      'O_Charges': oCharges,
      'MRP': mrp,
      'image_link': imageLink,
      'Table_Data': tableData.map((data) => data.toJson()).toList(),
    };
  }
}

class TableData {
  String lotDescription;
  String group;
  String units;
  int pcs;
  double weight;
  double rate;
  double value;
  double sRate;
  double sValue;

  TableData({
    required this.lotDescription,
    required this.group,
    required this.units,
    required this.pcs,
    required this.weight,
    required this.rate,
    required this.value,
    required this.sRate,
    required this.sValue,
  });

  factory TableData.fromJson(Map<String, dynamic> json) {
    return TableData(
      lotDescription: json['Lot_Description'],
      group: json['Group'],
      units: json['Units'],
      pcs: json['Pcs'],
      weight: json['Weight'].toDouble(),
      rate: json['Rate'].toDouble(),
      value: json['Value'].toDouble(),
      sRate: json['S_Rate'].toDouble(),
      sValue: json['S_Value'].toDouble(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'Lot_Description': lotDescription,
      'Group': group,
      'Units': units,
      'Pcs': pcs,
      'Weight': weight,
      'Rate': rate,
      'Value': value,
      'S_Rate': sRate,
      'S_Value': sValue,
    };
  }
}

