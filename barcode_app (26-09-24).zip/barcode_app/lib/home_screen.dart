import 'package:barcode_app/values/colors.dart';
import 'package:barcode_app/values/dimens.dart';
import 'package:barcode_app/values/styles.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'blocs/jewelry_bloc.dart';
import 'models/jewelry_item.dart';
import 'my_form.dart';

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key});

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  String? selectedBarcode;
  dynamic selectedItem;

  @override
  void initState() {
    super.initState();
    context.read<JewelryBloc>().add(LoadItems());
  }

  @override
  Widget build(BuildContext context) {
    var screenWidth = MediaQuery.of(context).size.width;
    // var screenHeight = MediaQuery.of(context).size.height;

    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        leading: Icon(
          Icons.menu,
          color: Colors.white,
          size: 32,
        ),
        forceMaterialTransparency: true,
        backgroundColor: Colors.transparent, // Transparent background
        elevation: 0, // Remove shadow
      ),
      body: BlocBuilder<JewelryBloc, JewelryState>(
        builder: (context, state) {
          if (state is JewelryInitial) {
            return Center(child: CircularProgressIndicator());
          } else if (state is JewelryLoaded) {
            return Container(
              decoration: const BoxDecoration(
                image: DecorationImage(
                  image: AssetImage('assets/images/background.png'),
                  fit: BoxFit.cover, // Cover the entire screen
                ),
              ),
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(36.0),
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                        height: Dim().d24,
                      ),
                      // Search bar with clear button
                      Padding(
                        padding: EdgeInsets.only(left: screenWidth * 0.04),
                        child: SizedBox(
                          width: Dim().d120,
                          height: Dim().d36,
                          child: ElevatedButton(
                              onPressed: () {},
                              style: ElevatedButton.styleFrom(
                                  elevation: 1,
                                  backgroundColor: Clr().white,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(8),
                                  )),
                              child: Center(
                                child: Text(
                                  'Details',
                                  style: Sty().mediumText.copyWith(
                                        fontSize: 12,
                                        fontWeight: FontWeight.w600,
                                      ),
                                ),
                              )),
                        ),
                      ),
                      SizedBox(
                        height: Dim().d8,
                      ),
                      Divider(
                        thickness: 0.5,
                      ),
                      SizedBox(
                        height: Dim().d8,
                      ),
                      SizedBox(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Row(
                              children: [
                                Container(
                                  height: 40,
                                  width: screenWidth * 0.65,
                                  // width: screenWidth * 0.1,
                                  decoration: BoxDecoration(
                                    color: Colors.grey[800],
                                    borderRadius: BorderRadius.circular(18),
                                  ),
                                  child: Padding(
                                    padding:
                                        EdgeInsets.symmetric(horizontal: 8.0),
                                    child: Row(
                                      children: [
                                        Icon(Icons.search,
                                            color: Colors.white54),
                                        SizedBox(
                                          width: 16,
                                        ),
                                        Container(
                                          width: screenWidth * 0.5,
                                          child: DropdownButton<String>(
                                            value: selectedBarcode,
                                            hint: Text('Select a Barcode'),
                                            items: state.items.map((item) {
                                              return DropdownMenuItem<String>(
                                                value: item.barcode,
                                                child: Text(item
                                                    .barcode,style: Sty().mediumText.copyWith(color: Colors.black),), // Ensure item is not null
                                              );
                                            }).toList(),
                                            underline: Container(),
                                            iconSize: 0.0,
                                            onChanged: (value) {
                                              setState(() {
                                                selectedBarcode = value;
                                                selectedItem = state.items
                                                    .firstWhere((item) =>
                                                        item.barcode ==
                                                        selectedBarcode);
                                              });
                                            },
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),

                            SizedBox(width: 10),
                            TextButton(
                              onPressed: () {

                                setState(() {
                                  selectedBarcode = null;  // Resetting selected barcode
                                });
                              },
                              child: Text('clear',
                                  style: TextStyle(color: Colors.blueAccent)),
                            )
                          ],
                        ),
                      ),


                      if (selectedBarcode != null) ...[
                        MyForm(
                          item: selectedItem,
                        ),
                        LayoutBuilder(
                          builder: (context, constraints) {
                            return SingleChildScrollView(
                              scrollDirection: Axis.horizontal,
                              // Enable horizontal scrolling on small screens
                              child: ConstrainedBox(
                                constraints: BoxConstraints(
                                  minWidth: constraints
                                      .maxWidth, // Make table width expand on larger screens
                                ),
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(12),
                                  child: _buildTableData(state.items.firstWhere(
                                      (item) =>
                                          item.barcode == selectedBarcode)),
                                ),
                              ),
                            );
                          },
                        ),
                      ],
                      if (selectedBarcode == null) Column(
                        children: [
                          MyFormEmpty(),

                          LayoutBuilder(
                            builder: (context, constraints) {
                              return SingleChildScrollView(

                                scrollDirection: Axis.horizontal, // Enable horizontal scrolling on small screens
                                child: ConstrainedBox(
                                  constraints: BoxConstraints(
                                    minWidth: constraints.maxWidth, // Make table width expand on larger screens
                                  ),
                                  child: ClipRRect(
                                    borderRadius: BorderRadius.circular(12),
                                    child: DataTable(
                                      dividerThickness: 0.00000000001,
                                      border: TableBorder.symmetric(borderRadius: BorderRadius.circular(12), inside: BorderSide.none,outside:  BorderSide.none,),
                                      decoration: BoxDecoration(color:Color(0xFF33353c), ),
                                      headingRowColor: WidgetStateProperty.resolveWith<Color>(
                                            (Set<WidgetState> states) {
                                          return Color(0xFF4b4d53);
                                        },
                                      ),
                                      dataTextStyle: Sty().smallText.copyWith(color: Clr().white),
                                      headingTextStyle:Sty().smallText.copyWith(color: Clr().white),
                                      columns: const [
                                        DataColumn(label: Text('LOT Description')),
                                        DataColumn(label: Text('Group')),
                                        DataColumn(label: Text('Units')),
                                        DataColumn(label: Text('Pcs')),
                                        DataColumn(label: Text('Weight')),
                                        DataColumn(label: Text('Rate')),
                                        DataColumn(label: Text('Value')),
                                        DataColumn(label: Text('S Rate')),
                                        DataColumn(label: Text('S Value')),
                                      ],
                                      rows: List<DataRow>.generate(
                                        3,
                                            (index) => const DataRow(
                                          cells: [
                                            DataCell(Text('')),
                                            DataCell(Text('')),
                                            DataCell(Text('')),
                                            DataCell(Text('')),
                                            DataCell(Text('')),
                                            DataCell(Text('')),
                                            DataCell(Text('')),
                                            DataCell(Text('')),
                                            DataCell(Text('')),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              );
                            },
                          ),
                        ],
                      )
                    ]),
              ),
            );
          } else if (state is JewelryError) {
            return Center(child: Text('Error: ${state.message}'));
          }
          return Column(
            children: [
              MyFormEmpty(),

              LayoutBuilder(
                builder: (context, constraints) {
                  return SingleChildScrollView(

                    scrollDirection: Axis.horizontal, // Enable horizontal scrolling on small screens
                    child: ConstrainedBox(
                      constraints: BoxConstraints(
                        minWidth: constraints.maxWidth, // Make table width expand on larger screens
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(12),
                        child: DataTable(
                          dividerThickness: 0.00000000001,
                          border: TableBorder.symmetric(borderRadius: BorderRadius.circular(12), inside: BorderSide.none,outside:  BorderSide.none,),
                          decoration: BoxDecoration(color:Color(0xFF33353c), ),
                          headingRowColor: WidgetStateProperty.resolveWith<Color>(
                                (Set<WidgetState> states) {
                              return Color(0xFF4b4d53);
                            },
                          ),
                          dataTextStyle: Sty().smallText.copyWith(color: Clr().white),
                          headingTextStyle:Sty().smallText.copyWith(color: Clr().white),
                          columns: [
                            DataColumn(label: Text('LOT Description')),
                            DataColumn(label: Text('Group')),
                            DataColumn(label: Text('Units')),
                            DataColumn(label: Text('Pcs')),
                            DataColumn(label: Text('Weight')),
                            DataColumn(label: Text('Rate')),
                            DataColumn(label: Text('Value')),
                            DataColumn(label: Text('S Rate')),
                            DataColumn(label: Text('S Value')),
                          ],
                          rows: List<DataRow>.generate(
                            3,
                                (index) => const DataRow(
                              cells: [
                                DataCell(Text('')),
                                DataCell(Text('')),
                                DataCell(Text('')),
                                DataCell(Text('')),
                                DataCell(Text('')),
                                DataCell(Text('')),
                                DataCell(Text('')),
                                DataCell(Text('')),
                                DataCell(Text('')),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _buildTableData(JewelryItem item) {
    return DataTable(
      dividerThickness: 0.00000000001,
      border: TableBorder.symmetric(
        borderRadius: BorderRadius.circular(12),
        inside: BorderSide.none,
        outside: BorderSide.none,
      ),
      decoration: BoxDecoration(
        color: Color(0xFF33353c),
      ),
      headingRowColor: WidgetStateProperty.resolveWith<Color>(
        (Set<WidgetState> states) {
          return Color(0xFF4b4d53);
        },
      ),
      dataTextStyle: Sty().smallText.copyWith(color: Clr().white),
      headingTextStyle: Sty().smallText.copyWith(color: Clr().white),
      columns: const [
        DataColumn(label: Text('LOT Description')),
        DataColumn(label: Text('Group')),
        DataColumn(label: Text('Units')),
        DataColumn(label: Text('Pcs')),
        DataColumn(label: Text('Weight')),
        DataColumn(label: Text('Rate')),
        DataColumn(label: Text('Value')),
        DataColumn(label: Text('S Rate')),
        DataColumn(label: Text('S Value')),
      ],
      rows: item.tableData
          .map((tableData) => DataRow(cells: [
                DataCell(Text(tableData.lotDescription)),
                DataCell(Text(tableData.group)),
                DataCell(Text(tableData.units)),
                DataCell(Text(tableData.pcs.toString())),
                DataCell(
                  Text(tableData.weight.toString()),
                ),
                DataCell(
                  Text(tableData.rate.toString()),
                ),
                DataCell(
                  Text(tableData.value.toString()),
                ),
                DataCell(
                  Text(tableData.sRate.toString()),
                ),
                DataCell(
                  Text(tableData.sValue.toString()),
                ),
              ]))
          .toList(),
    );
  }
}
