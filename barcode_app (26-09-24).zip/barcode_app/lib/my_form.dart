import 'package:barcode_app/values/colors.dart';
import 'package:barcode_app/values/styles.dart';
import 'package:flutter/material.dart';

import 'models/jewelry_item.dart';

class MyForm extends StatelessWidget {
  final JewelryItem item;

  // Accepting JewelryItem as a parameter
  const MyForm({super.key, required this.item});

  @override
  Widget build(BuildContext context) {
    var screenWidth = MediaQuery.of(context).size.width;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 16.0),
      child: Column(
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Left side with TextFormFields
              Expanded(
                flex: 7,
                child: Column(
                  children: [
                    // First 4 rows with customized layout
                    _buildTextFormFields(
                      context,
                      [
                        ['Barcode No.', 'Location', 'Branch', 'Status', 'Counter'],
                        ['Source', 'Category', 'Collection', 'Description', ''],
                        ['Metal Grp', 'STK Section', 'Mfgd By', 'Notes', ''],
                        ['In STK Since', 'Cert No.', 'HUID No.', 'Order No.', 'Cus Name'],
                      ],
                      item, // Passing the JewelryItem data here
                    ),
                    const SizedBox(height: 12),
                  ],
                ),
              ),

              // Right side with Image container
              const SizedBox(width: 16),
              Expanded(
                flex: 3,
                child: Container(
                  height: 200,
                  decoration: BoxDecoration(
                    color: Colors.grey[300],
                    border: Border.all(color: Colors.black),
                  ),
                  child: Center(
                    child: _buildJewelryImage(item), // Displaying image from JewelryItem
                  ),
                ),
              ),
            ],
          ),
          Row(
            children: [
              Expanded(
                child: _buildTextFormFields(
                  context,
                  [
                    ['Size', 'Quality', 'KT', 'Pcs', 'Gross Wt', 'Net Wt'],
                    ['Dia Pcs', 'Dia Wt', 'Cls Pcs', 'Cls Wt', 'Chain Wt', 'M Rate'],
                    ['M Value', 'L Rate', 'L Charges', 'R Charges', 'O Charges', 'MRP'],
                  ],
                  item, // Passing the JewelryItem data here
                ),
              ),
              SizedBox(width: screenWidth * 0.05),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildTextFormFields(
      BuildContext context, List<List<String>> rows, JewelryItem item) {
    // Map JewelryItem fields to values
    Map<String, String> fieldValues = {
      'Barcode No.': item.barcode,
      'Location': item.location ,
      'Branch': item.branch,
      'Status': item.status,
      'Counter': item.counter.toString(),
      'Source': item.source,
      'Category': item.category,
      'Collection': item.collection ,
      'Description': item.description,
      'Metal Grp': item.metalGrp,
      'STK Section': item.stkSection,
      'Mfgd By': item.mfgdBy ,
      'Notes': item.notes ,
      'In STK Since': item.inStkSince ,
      'Cert No.': item.certNo,
      'HUID No.': item.huidNo,
      'Order No.': item.orderNo.toString(),
      'Cus Name': item.cusName,
      'Size': item.size.toString(),
      'Quality': item.quality,
      'KT': item.kt.toString(),
      'Pcs': item.pcs.toString(),
      'Gross Wt': item.grossWt.toString(),
      'Net Wt': item.netWt.toString(),
      'Dia Pcs': item.diaPcs.toString(),
      'Dia Wt': item.diaWt.toString(),
      'Cls Pcs': item.clsPcs.toString(),
      'Cls Wt': item.clsWt.toString(),
      'Chain Wt': item.chainWt.toString(),
      'M Rate': item.mRate.toString(),
      'M Value': item.mValue.toString(),
      'L Rate': item.lRate.toString(),
      'L Charges': item.lCharges.toString(),
      'R Charges': item.rCharges.toString(),
      'O Charges': item.oCharges.toString(),
      'MRP': item.mrp.toString(),
    };

    return Column(
      children: rows.map((row) {
        return Row(
          children: row.map((label) {
            if (label.contains('(merged)')) {
              return Expanded(
                flex: 3,
                child: Padding(
                  padding: const EdgeInsets.all(4.0),
                  child: _buildTextField(
                    label.replaceAll('(merged)', ''), // Remove "(merged)" from label
                    fieldValues[label.replaceAll('(merged)', '')] ?? '', // Pass the corresponding value
                  ),
                ),
              );
            } else if (label.isNotEmpty) {
              return Expanded(
                flex: 2,
                child: Padding(
                  padding: const EdgeInsets.all(4.0),
                  child: _buildTextField(label, fieldValues[label] ?? ''), // Pass the corresponding value
                ),
              );
            } else {
              return const Expanded(child: SizedBox.shrink());
            }
          }).toList(),
        );
      }).toList(),
    );
  }

  // Helper method to create a TextFormField with borders and initial value
  Widget _buildTextField(String label, String initialValue) {
    return TextFormField(
      readOnly: true,
      style: Sty().mediumText.copyWith(color: Clr().white),
      initialValue: initialValue, // Set the initial value
      decoration: InputDecoration(
        labelText: label,

        filled: true,
        fillColor: const Color(0xff141720),
        labelStyle: Sty().mediumText.copyWith(color: Clr().white, fontWeight: FontWeight.w400, fontSize: 14),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(
            width: 0.2,
            color: Clr().white,
          ),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(
            color: Clr().primaryColor,
          ),
        ),
        border: const OutlineInputBorder(
          borderSide: BorderSide(color: Colors.black),
        ),
      ),
    );
  }

  Widget _buildJewelryImage(JewelryItem item) {
    return Image.network(
      item.imageLink,
      fit: BoxFit.contain,
      height: double.infinity,
      width: double.infinity,
    );
  }
}





/// only for show empty data
class MyFormEmpty extends StatelessWidget {
  const MyFormEmpty({super.key});

  @override
  Widget build(BuildContext context) {
    var screenWidth = MediaQuery.of(context).size.width;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 16.0),
      child: Column(
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Left side with TextFormFields
              Expanded(
                flex: 7,
                child: Column(
                  children: [
                    // First 4 rows with customized layout
                    _buildTextFormFields(
                      context,
                      [
                        ['Barcode No.', 'Location', 'Branch', 'Status', 'Counter'],
                        ['Source', 'Category', 'Collection', 'Description (merged)', ''],
                        ['Metal Grp', 'STK Section', 'Mfgd By', 'Notes (merged)', ''],
                        ['In STK Since', 'Cert No.', 'HUID No.', 'Order No.', 'Cus Name'],
                      ],
                    ),
                    const SizedBox(height: 12),


                  ],
                ),
              ),

              // Right side with Image container
              const SizedBox(width: 16),
              Expanded(
                flex: 3,
                child: Container(
                  height: 200,
                  decoration: BoxDecoration(
                    color: Colors.grey[300],
                    border: Border.all(color: Colors.black),
                  ),
                  child: const Center(
                    child: Text('Display Image Here'),
                  ),
                ),

              ),

              // Last 3 rows with 6 TextFormFields in each row

            ],
          ),
          Row(
            children: [
              Expanded(
                child: _buildTextFormFields(
                  context,
                  [
                    ['Size', 'Quality', 'KT', 'Pcs', 'Gross Wt', 'Net Wt'],
                    ['Dia Pcs', 'Dia Wt', 'Cls Pcs', 'Cls Wt', 'Chain Wt', 'M Rate'],
                    ['M Value', 'L Rate', 'L Charges', 'R Charges', 'O Charges', 'MRP'],
                  ],
                ),
              ),
              SizedBox(width: screenWidth* 0.05 ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildTextFormFields(BuildContext context, List<List<String>> rows) {
    return Column(
      children: rows.map((row) {
        return Row(

          children: row.map((label) {
            // Adjust for the merged cells
            if (label.contains('(merged)')) {
              return Expanded(
                flex: 3,
                child: Padding(
                  padding: const EdgeInsets.all(4.0),
                  child: _buildTextField(label.replaceAll('(merged)', '')), // Remove "(merged)" from label
                ),
              );
            } else if (label.isNotEmpty) {
              return Expanded(
                flex: 2,  // Normal fields take flex=1
                child: Padding(
                  padding: const EdgeInsets.all(4.0),
                  child: _buildTextField(label),
                ),
              );
            } else {
              return const Expanded(child: SizedBox.shrink());  // Empty space
            }
          }).toList(),
        );
      }).toList(),
    );
  }


  // Helper method to create a TextFormField with borders
  Widget _buildTextField(String label) {
    return TextFormField(

      decoration: InputDecoration(

        labelText: label,
        filled: true,
        fillColor: const Color(0xff141720),
        labelStyle: Sty().mediumText.copyWith(color: Clr().white,fontWeight: FontWeight.w400,fontSize: 14),
        enabledBorder: OutlineInputBorder(

          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(
            width: 0.2,
            color: Clr().white,
          ),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(
            color: Clr().primaryColor,
          ),
        ),
        border: const OutlineInputBorder(
          borderSide: BorderSide(color: Colors.black),

        ),
      ),
    );
  }
}