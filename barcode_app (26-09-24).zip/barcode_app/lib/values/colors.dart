import 'package:flutter/material.dart';

class Clr {
  Color primaryColor = const Color(0xFFC91DA9);
  Color white = const Color(0xFFFFFFFF);
  Color errorRed = const Color(0xFFB00020);
  Color lightGrey = const Color(0xFFF4F4F4);
  Color hintColor = const Color(0xFF868686);
  Color background = const Color(0xFFF8F8FB);
  Color black = const Color(0xFF000000);
  Color grey = const Color(0xFFC5C5C5);
  Color shimmerColor = const Color(0xFFABABAB);

}