import 'dart:convert';
import 'package:barcode_app/models/jewelry_item.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter/services.dart';

// Events
abstract class JewelryEvent {}

class LoadItems extends JewelryEvent {}

// States
abstract class JewelryState {}

class JewelryInitial extends JewelryState {}

class JewelryLoaded extends JewelryState {
  final List<JewelryItem> items;

  JewelryLoaded(this.items);
}

class JewelryError extends JewelryState {
  final String message;

  JewelryError(this.message);
}

// Bloc
class JewelryBloc extends Bloc<JewelryEvent, JewelryState> {
  JewelryBloc() : super(JewelryInitial()) {
    on<LoadItems>((event, emit) async {
      try {
        final String response =
        await rootBundle.loadString('assets/json/jewelry_data.json');
        final data = json.decode(response);
        List<JewelryItem> items = (data['Items'] as List)
            .map((item) => JewelryItem.fromJson(item))
            .toList();
        emit(JewelryLoaded(items));
      } catch (e) {
        emit(JewelryError(e.toString()));
      }
    });
  }
}
